PyLodge
=======

PyLodge is a framework that integrates the automated tests with Test Lodge. It will update the status of the test cases
in Test Lodge based on the execution status of the automation script. In case of Failed test cases, it will create a
 defect in the issue tracker if the project in Test Lodge has the issue tracker configured.

